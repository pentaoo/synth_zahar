import {renderScore} from './score.mjs';
self.onmessage = ({data}) => {
  try {
    const score=renderScore(data.sampleRate,data.waves);
    self.postMessage(score,score.stems.map(stem=>stem.buffer));
  } catch(error) { self.postMessage({error:error.message}); }
};
