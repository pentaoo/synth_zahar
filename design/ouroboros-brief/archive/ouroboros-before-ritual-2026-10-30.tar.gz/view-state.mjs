export class ViewState {
  constructor(){this.progress=0;this.target=0;this.selected=0;this.pending=null;this.rotation=0;this.focusAngle=-Math.PI/2;this.live=false;}
  open(index,rotation=0,reduced=false){
    if(index<0||index>2)return;
    if(this.progress>0&&this.selected!==index){if(this.progress===1){this.focusAngle=this.displayAngle??this.focusAngle;this.live=false;}this.pending={index,rotation};this.target=0;}
    else{if(this.progress===0){this.focusAngle=-Math.PI/2;this.live=false;}this.selected=index;this.rotation=rotation;this.pending=null;this.target=1;}
    if(reduced){this.selected=index;this.rotation=rotation;this.progress=1;this.target=1;this.pending=null;}
  }
  close(reduced=false,angle=this.focusAngle){this.pending=null;this.target=0;if(this.progress===1){this.focusAngle=angle;this.live=false;}if(reduced)this.progress=0;}
  update(dt,reduced=false){
    if(reduced)this.progress=this.target;
    else{const step=Math.min(.06,dt)/2.8;this.progress+=Math.max(-step,Math.min(step,this.target-this.progress));}
    if(this.progress===0&&this.pending){const next=this.pending;this.pending=null;this.selected=next.index;this.rotation=next.rotation;this.focusAngle=-Math.PI/2;this.live=false;this.target=1;}
    return this.progress;
  }
  get settled(){return this.progress===this.target&&!this.pending;}
}
export class Finale {
  constructor(){this.reset();}
  reset(){this.state='ready';this.progress=0;this.paused=false;this.pose=null;}
  begin(){if(this.state!=='ready')return false;this.state='closing';this.progress=0;this.paused=false;return true;}
  update(dt,reduced=false){if(this.state==='closing'&&!this.paused){this.progress=Math.min(1,this.progress+(reduced?1:dt/1.05));if(this.progress===1)this.state='ended';}return this.progress;}
  togglePause(){if(this.state==='closing')this.paused=!this.paused;}
}
