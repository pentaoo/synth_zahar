import {TAU,RINGS,ATLAS,HEAD_UNITS,ringMetrics,bodyPoint,sampleBody,presentation,collapsePresentation,project,unproject,hitBody} from './body-geometry.mjs?v=revision-6';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);};
const loadImage=async src=>{const im=new Image();im.src=src;await im.decode();return im;};
export class EngravingRenderer {
  constructor(canvas,inkCanvas){
    this.canvas=canvas;this.inkCanvas=inkCanvas;this.ctx=inkCanvas.getContext('2d');
    this.gl=canvas.getContext('webgl2',{alpha:false,antialias:true,preserveDrawingBuffer:true});
    if(!this.gl)throw new Error('Для растровой гравюры нужен WebGL 2. Открой инструмент в актуальном Chrome.');
    this.vertices=new Float32Array(514*2*4);this.path=new Float32Array(513*5);this.headVertices=new Float32Array(65*8);this.matrix=new Float32Array(9);this.segments=384;this.width=0;this.height=0;this.ready=false;
    this.grain=this.makeGrain();
  }
  async initialize(){
    const head=await loadImage(new URL('./assets/engraved-atlas-v2.png',import.meta.url));
    const gl=this.gl;
    const shader=(type,source)=>{const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;};
    const vs=shader(gl.VERTEX_SHADER,`#version 300 es
      precision highp float; in vec2 a_position; in vec2 a_uv; uniform mat3 u_view; uniform vec2 u_resolution; out vec2 v_uv;
      void main(){vec3 p=u_view*vec3(a_position,1.);gl_Position=vec4(p.x/u_resolution.x*2.-1.,1.-p.y/u_resolution.y*2.,0.,1.);v_uv=a_uv;}`);
    const fs=shader(gl.FRAGMENT_SHADER,`#version 300 es
      precision highp float; in vec2 v_uv; uniform sampler2D u_texture; uniform float u_alpha; uniform bool u_skin; out vec4 color;
      void main(){vec2 uv=v_uv;if(u_skin){uv.x=mix(.4,.98,1.-abs(fract(uv.x*.5)*2.-1.));uv.y=mix(220./724.,516./724.,uv.y);}color=texture(u_texture,uv);color.a*=u_alpha;}`);
    this.program=gl.createProgram();gl.attachShader(this.program,vs);gl.attachShader(this.program,fs);gl.linkProgram(this.program);
    if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(this.program));
    gl.useProgram(this.program);this.buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.bufferData(gl.ARRAY_BUFFER,this.vertices.byteLength,gl.DYNAMIC_DRAW);
    for(const [name,size,offset] of [['a_position',2,0],['a_uv',2,8]]){const at=gl.getAttribLocation(this.program,name);gl.enableVertexAttribArray(at);gl.vertexAttribPointer(at,size,gl.FLOAT,false,16,offset);}
    this.uniforms={};for(const key of ['u_view','u_resolution','u_alpha','u_skin'])this.uniforms[key]=gl.getUniformLocation(this.program,key);
    const texture=image=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);return t;};
    this.skinTexture=this.headTexture=texture(head);this.headImage=head;
    const mask=document.createElement('canvas');mask.width=head.width;mask.height=head.height;const mc=mask.getContext('2d',{willReadFrequently:true});mc.drawImage(head,0,0);this.headPixels=mc.getImageData(0,0,head.width,head.height).data;
    gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);this.ready=true;
  }
  makeGrain(){
    const c=document.createElement('canvas');c.width=c.height=512;const x=c.getContext('2d');x.fillStyle='#070707';x.fillRect(0,0,512,512);
    let seed=7219;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    for(let i=0;i<18000;i++){const px=random()*512,py=random()*512,r=.25+random()*.65;x.fillStyle=i%4?'#272727':'#e9e9e7';x.beginPath();x.ellipse(px,py,r,r*.65,random()*3,0,TAU);x.fill();}
    return c;
  }
  resize(width,height,dpr){this.width=width;this.height=height;this.dpr=Math.min(2,dpr||1);for(const c of [this.canvas,this.inkCanvas]){c.width=Math.round(width*this.dpr);c.height=Math.round(height*this.dpr);}this.gl.viewport(0,0,this.canvas.width,this.canvas.height);this.ctx.setTransform(this.dpr,0,0,this.dpr,0,0);this.pattern=this.ctx.createPattern(this.grain,'repeat');}
  setCamera(view){
    const gl=this.gl,c=Math.cos(view.rotation)*view.scale,s=Math.sin(view.rotation)*view.scale;
    const m=this.matrix;m[0]=c;m[1]=s;m[2]=0;m[3]=-s;m[4]=c;m[5]=0;m[6]=view.tx;m[7]=view.ty;m[8]=1;
    gl.uniformMatrix3fv(this.uniforms.u_view,false,m);
  }
  body(ring,view,bend,alpha,scratch,ink,reduced,mini=false){
    if(ring.thickness<.01||ring.length<=0||alpha<=.001)return;
    const gl=this.gl,v=this.vertices,n=mini?96:this.segments,w=ring.thickness,path=sampleBody(ring,bend,n,this.path);
    for(let j=0;j<=n;j++){
      const at=j*5,material=path[at+4],p={x:path[at],y:path[at+1],tx:path[at+2],ty:path[at+3]},angle=Math.atan2(p.y,p.x);
      const delta=Math.atan2(Math.sin(angle-scratch.angle),Math.cos(angle-scratch.angle));
      const neck=smooth(material/Math.max(1,ring.baseWidth));
      const local=Math.exp(-delta*delta/(2*.2*.2))*scratch.strength*neck;
      const tooth=.5+.5*Math.cos(material/(ring.baseWidth*.19)*TAU);
      const rise=reduced?0:local*w*(.16+.2*tooth);
      const lean=reduced?0:local*scratch.direction*w*.12;
      const press=ring.index===2&&bend===0?ink.pressureAt(angle)*w*.22*neck:0;
      const taper=ring.fullLength-material<ring.baseWidth*2.7?Math.max(.10,(ring.fullLength-material)/(ring.baseWidth*2.7)):1;
      for(let side=0;side<2;side++){
        const amount=(side===0?-1:1)*w*.5*taper-(side===0?rise:0)-press;
        const k=(j*2+side)*4;v[k]=p.x+p.ty*amount+(side===0?p.tx*lean:0);v[k+1]=p.y-p.tx*amount+(side===0?p.ty*lean:0);v[k+2]=material/ring.tileLength;v[k+3]=side;
      }
    }
    this.setCamera(view);gl.uniform1f(this.uniforms.u_alpha,alpha);gl.uniform1i(this.uniforms.u_skin,1);gl.bindTexture(gl.TEXTURE_2D,this.skinTexture);gl.bufferSubData(gl.ARRAY_BUFFER,0,v.subarray(0,(n+1)*8));gl.drawArrays(gl.TRIANGLE_STRIP,0,(n+1)*2);
    this.head(ring,alpha,bend,mini);
  }
  head(ring,alpha,path=0,mini=false){
    const gl=this.gl,w=ring.thickness,v=this.headVertices,n=mini?24:64;
    for(let j=0;j<=n;j++){
      const u=j/n*ATLAS.neck,p=bodyPoint(ring,(j/n-1)*w*HEAD_UNITS,path);
      for(let side=0;side<2;side++){
        const y=(side-ATLAS.center)*ATLAS.height/296*w,k=(j*2+side)*4;
        v[k]=p.x+p.ty*y;v[k+1]=p.y-p.tx*y;v[k+2]=u;v[k+3]=side;
      }
    }
    gl.uniform1i(this.uniforms.u_skin,0);gl.uniform1f(this.uniforms.u_alpha,alpha);gl.bindTexture(gl.TEXTURE_2D,this.headTexture);gl.bufferSubData(gl.ARRAY_BUFFER,0,v.subarray(0,(n+1)*8));gl.drawArrays(gl.TRIANGLE_STRIP,0,(n+1)*2);
  }
  headHit(point,rings,view,selected=-1,path=0){
    const p=unproject(point,view);
    for(const ring of rings){
      if(selected>=0&&ring.index!==selected)continue;
      if(ring.thickness<.01)continue;
      for(let j=0;j<=48;j++){
        const material=(j/48-1)*ring.thickness*HEAD_UNITS,a=bodyPoint(ring,material,path),dx=p.x-a.x,dy=p.y-a.y;
        const along=dx*a.tx+dy*a.ty;if(Math.abs(along)>ring.thickness*HEAD_UNITS/48)continue;
        const u=(material+along)/(ring.thickness*HEAD_UNITS)*ATLAS.neck+ATLAS.neck,v=(dx*a.ty-dy*a.tx)/(ring.thickness*ATLAS.height/296)+ATLAS.center;
        if(u<0||u>=ATLAS.neck||v<0||v>=1)continue;
        const at=(Math.floor(v*this.headImage.height)*this.headImage.width+Math.floor(u*this.headImage.width))*4;
        if(this.headPixels[at+3]>110)return {channel:ring.index,s:material,angle:Math.atan2(p.y,p.x),ring,distance:0};
      }
    }
    return null;
  }
  hit(point){if(!this.ready||!this.scene||!this.scene.visible)return null;const {rings,view,bend,focus}=this.scene;return this.headHit(point,rings,view,focus,bend)||hitBody(point,rings,view,bend,focus);}
  ink(ink,view,windowRadius,alpha=1){
    if(alpha<.001||windowRadius<=0)return;
    const ctx=this.ctx,c=Math.cos(view.rotation)*view.scale,s=Math.sin(view.rotation)*view.scale;
    ctx.save();ctx.transform(c,s,-s,c,view.tx,view.ty);ctx.globalAlpha=alpha;
    ctx.beginPath();ctx.arc(0,0,windowRadius,0,TAU);ctx.clip();
    const p=ink.points,n=ink.count;ctx.beginPath();ctx.moveTo((p[0]+p[(n-1)*2])/2,(p[1]+p[(n-1)*2+1])/2);
    for(let i=0;i<n;i++){const next=(i+1)%n;ctx.quadraticCurveTo(p[i*2],p[i*2+1],(p[i*2]+p[next*2])/2,(p[i*2+1]+p[next*2+1])/2);}ctx.closePath();ctx.fillStyle=this.pattern;ctx.fill();
    for(const d of ink.droplets){ctx.beginPath();ctx.ellipse(d.x,d.y,d.r,d.r*.82,Math.atan2(d.vy,d.vx),0,TAU);ctx.fill();}
    ctx.restore();
  }
  render({baseRadius,compression,phase,viewState,ink,scratch,finale=0,finalePose=null,reduced=false}){
    if(!this.ready)return;
    const gl=this.gl,{width,height}=this,p=viewState.progress;
    const rings=RINGS.map((_,i)=>ringMetrics(i,baseRadius,compression,phase,finale));
    const selectedRing=rings[viewState.selected];let layout=presentation(width,height,baseRadius,selectedRing,viewState);
    if(finalePose)layout=collapsePresentation(layout,finalePose,finale);
    const {view,overview,remaining,mini}=layout,bend=layout.path;
    if(p===1&&!finalePose){
      if(!viewState.live){viewState.phaseAnchor=phase;viewState.angleAnchor=viewState.focusAngle;viewState.live=true;}
      selectedRing.headAngle=viewState.angleAnchor+(phase-viewState.phaseAnchor)*TAU;
    }else selectedRing.headAngle=layout.angle;
    viewState.displayAngle=selectedRing.headAngle;
    gl.disable(gl.SCISSOR_TEST);gl.clearColor(1,1,1,1);gl.clear(gl.COLOR_BUFFER_BIT);gl.useProgram(this.program);gl.uniform2f(this.uniforms.u_resolution,width,height);
    this.ctx.clearRect(0,0,width,height);
    if(layout.visible)this.body(selectedRing,view,bend,1,scratch,ink,reduced);
    for(const ring of rings)if(ring.index!==viewState.selected)this.body(ring,remaining,0,1,scratch,ink,reduced,p>.54);
    const windowRadius=Math.max(0,rings[2].radius-rings[2].thickness*.65);
    this.ink(ink,remaining,windowRadius,1);
    this.scene={rings,view,bend,focus:p>0?viewState.selected:-1,overview,remaining,windowRadius,mini,miniActive:layout.miniActive,visible:layout.visible,stage:layout.stage};
    return this.scene;
  }
}
