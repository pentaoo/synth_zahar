import {OuroborosAudio} from './engine.mjs?v=revision-6';
import {BPM,BEATS,clamp,wrap} from './score.mjs';
import {WheelScratch} from './wheel-scratch.mjs';
import {PinchScale,MIN_SCALE} from './pinch-scale.mjs?v=engraving-2';
import {HandMotion,ScratchResponse,SCRATCH_INPUT} from './scratch-motion.mjs';
import {RINGS,TAU,sceneSize,ringMetrics,bodyPoint,project,unproject,BodyIntent} from './body-geometry.mjs?v=revision-6';
import {shortcut} from './input-shortcuts.mjs';
import {ViewState,Finale} from './view-state.mjs?v=revision-6';
import {InkMass} from './ink-physics.mjs?v=engraving-2';
import {EngravingRenderer} from './engraving-renderer.mjs?v=revision-6';

const $=id=>document.getElementById(id),root=$('ouroboros'),stage=$('stage'),canvas=$('canvas'),inkButton=$('ink'),probe=$('audio-state'),panel=$('channel-panel'),minimap=$('minimap'),dialog=$('sound-dialog');
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
const transportKind=new URLSearchParams(location.search).get('transport')==='slip'?'slip':'vinyl';
const model={phase:0,backgroundPhase:0,speed:0,rate:1,peak:0,playing:false,scratching:false,queued:-1};
const view=new ViewState(),finale=new Finale(),ink=new InkMass(),hand=new HandMotion(),scratchVisual=new ScratchResponse();
let renderer,width=0,height=0,baseRadius=100,gesture=null,keyboard=null,starting=null,restarting=false,lastFrame=performance.now(),lastStateAt=performance.now(),pinchTimer,pinchTicket=0,statusTimer,lastSelected=-1,lastProbe=0,focusPending=false,returnFocus=false,compressionPressure=0,keyboardChannel=0;
const audio=new OuroborosAudio(state=>{
  Object.assign(model,state);lastStateAt=performance.now();sync();
  probe.dataset.phase=state.phase.toFixed(6);probe.dataset.speed=state.speed.toFixed(3);probe.dataset.rate=(state.rate||1).toFixed(4);
  probe.dataset.peak=state.peak.toFixed(5);probe.dataset.scratching=String(state.scratching);probe.dataset.transport=transportKind;
  probe.dataset.minSpeed=Math.min(Number(probe.dataset.minSpeed||0),state.speed).toFixed(3);
  probe.dataset.modeMix=(state.modeMix||0).toFixed(3);
  if(transportKind==='slip'){probe.dataset.backgroundPhase=(state.backgroundPhase||0).toFixed(6);probe.dataset.slipMix=(state.slipMix||0).toFixed(4);}
  else{
    probe.dataset.releaseCount=String(state.releaseCount||0);if(Number.isFinite(state.releasePhase))probe.dataset.releasePhase=state.releasePhase.toFixed(6);
    probe.dataset.coasting=String(!!state.coasting);probe.dataset.coastVelocity=(state.coastVelocity||0).toFixed(3);
    probe.dataset.coastStarts=String(state.coastStarts||0);probe.dataset.texturePeak=(state.texturePeak||0).toFixed(5);
  }
},{transport:transportKind});
root.dataset.transport=transportKind;
root.dataset.modality='pointer';
window.addEventListener('pointerdown',()=>{root.dataset.modality='pointer';},true);
window.addEventListener('keydown',()=>{root.dataset.modality='keyboard';},true);
if(transportKind==='slip'){$('transport-description').textContent='Сохранённый Slip: после штриха музыка возвращается в текущее фоновое время.';$('texture-routing').hidden=true;}
const wheel=new WheelScratch({
  grab:()=>audio.grab(),motion:(v,a)=>applyScratch(v,a),release:options=>audio.release(options),
  changed:state=>{root.dataset.wheelScratching=String(state.active);if(!gesture)stage.dataset.gesture=state.active?'scratch':'';}
});
const pinch=new PinchScale({
  started:()=>{clearTimeout(pinchTimer);pinchTicket++;wheel.suspend(performance.now());endGesture();audio.cancelScratch();scratchVisual.clear();root.dataset.pinching='true';},
  changed:(scale,rate)=>{audio.setRate(rate);root.dataset.scale=scale.toFixed(4);probe.dataset.scale=scale.toFixed(4);probe.dataset.targetRate=rate.toFixed(4);layoutInk();},
  boundary:value=>{if(finale.state!=='ready')return;compressionPressure+=Math.max(0,Math.log(MIN_SCALE/value));if(compressionPressure>.18)beginFinale();},
  ended:()=>{wheel.resume(performance.now());root.dataset.pinching='false';compressionPressure=0;}
});
root.dataset.momentum=typeof WheelEvent!=='undefined'&&'momentum' in WheelEvent.prototype?'native':'heuristic';
function message(text,persistent=false){clearTimeout(statusTimer);$('status').textContent=text;if(text&&!persistent)statusTimer=setTimeout(()=>{$('status').textContent='';},2600);}
function endPinch(){clearTimeout(pinchTimer);pinchTicket++;pinch.end();}
function applyScratch(v,angle){audio.motion(v);scratchVisual.excite(v,angle,performance.now());probe.dataset.inputVelocity=v.toFixed(3);}
function sync(){
  root.dataset.running=String(audio.playing);
  root.setAttribute('aria-label','Музыкальный инструмент Уроборос. '+(finale.state==='ended'?'Круг завершён. Пробел — новый круг.':audio.playing?'Играет. Пробел — пауза.':'Пауза. Пробел — играть.'));
}

async function start(){
  if(finale.state!=='ready'||restarting)return false;
  if(audio.playing)return true;if(starting)return starting;
  root.dataset.loading='true';
  starting=(async()=>{try{const ok=await audio.play();if(ok)message('');return ok;}catch(e){message(e.message,true);return false;}finally{starting=null;root.dataset.loading='false';sync();}})();
  return starting;
}
function endGesture(){
  if(gesture?.type==='scratch'||keyboard==='scratch')audio.release();
  audio.endInk();ink.release();gesture=null;keyboard=null;hand.reset();stage.dataset.gesture=wheel.active?'scratch':'';
}
function cancelGesture(){wheel.cancel();endGesture();audio.cancelScratch();scratchVisual.clear();}
function pause(){
  endPinch();wheel.reset();endGesture();audio.pause();scratchVisual.clear();
  if(finale.state==='closing')finale.paused=true;sync();
}
function togglePlay(){
  if(finale.state==='ended')return restart();
  if(finale.state==='closing'){finale.togglePause();sync();return;}
  return audio.playing||starting||restarting?pause():start();
}
function beginFinale(){
  if(!finale.begin())return;
  const scene=renderer?.scene;
  if(scene)finale.pose={view:{...scene.view},remaining:{...scene.remaining},path:scene.bend,angle:scene.rings[view.selected].headAngle};
  cancelGesture();endPinch();view.target=view.progress;view.pending=null;focusPending=returnFocus=false;audio.finish();root.dataset.finale='closing';message('');sync();
}
async function restart(){
  if(restarting)return;restarting=true;
  finale.reset();view.close(true);ink.reset();compressionPressure=0;pinch.set(1);root.dataset.finale='ready';
  try{await audio.restart();}catch(e){message(e.message,true);}finally{restarting=false;sync();}
}
function openChannel(index,angle=0){
  if(finale.state!=='ready')return;
  view.open(index,angle,reduced.matches);keyboardChannel=index;focusPending=true;returnFocus=false;
}
function closeView(){view.close(reduced.matches,renderer?.scene?.rings[view.selected].headAngle);focusPending=false;returnFocus=true;}
minimap.addEventListener('click',closeView);
function coordinates(event){const r=stage.getBoundingClientRect();return {x:event.clientX-r.left,y:event.clientY-r.top};}
function eventTime(event){const now=performance.now();return Number.isFinite(event.timeStamp)&&Math.abs(event.timeStamp-now)<60000?event.timeStamp:now;}
function moveInk(point,time){
  if(!renderer?.scene)return;
  const scene=renderer.scene,p=unproject(point,scene.overview),r=Math.max(1,scene.windowRadius);
  const x=clamp(.5+p.x/(r*2),0,1),y=clamp(.5-p.y/(r*2),0,1),previous=gesture?.inkPosition;
  const dt=Math.max(.008,(time-(gesture?.lastAt||time-16))/1000);
  const energy=previous?clamp(Math.hypot(x-previous.x,y-previous.y)/dt*.13,0,1):0;
  ink.touch((x-.5)*2,(.5-y)*2);audio.moveInk(x,y,energy);
  if(gesture){gesture.lastAt=time;gesture.inkPosition={x,y};}
  return {x,y};
}
stage.addEventListener('pointerdown',async event=>{
  if(event.button!==0||gesture||pinch.source||restarting||finale.state!=='ready'||!renderer?.scene)return;
  if(event.target.closest('button')&&event.target!==inkButton)return;
  const p=coordinates(event),hit=renderer.hit(p),scene=renderer.scene;
  const inInk=view.progress<.02&&Math.hypot(p.x-scene.overview.tx,p.y-scene.overview.ty)<scene.windowRadius;
  if(!hit&&!inInk)return;
  event.preventDefault();stage.setPointerCapture(event.pointerId);
  const current={type:hit?'body':'ink',pointer:event.pointerId,hit,intent:new BodyIntent(p.x,p.y,eventTime(event)),last:p,lastAt:performance.now(),velocity:0,ready:false,started:false};gesture=current;hand.reset();
  if(hit){canvas.focus({preventScroll:true});stage.dataset.gesture='held';}
  else{
    inkButton.focus({preventScroll:true});stage.dataset.gesture='ink';const xy=moveInk(p,performance.now());
    if(await start()&&gesture===current){current.ready=true;audio.startInk(xy.x,xy.y);probe.dataset.inkGestures=String(Number(probe.dataset.inkGestures||0)+1);}
  }
});
async function beginScratch(current){
  if(current.started)return;current.started=true;current.type='scratch';wheel.cancel();audio.cancelScratch();stage.dataset.gesture='scratch';
  if(await start()&&gesture===current){current.ready=true;audio.grab();if(current.velocity)applyScratch(current.velocity,current.hit.angle);}
}
stage.addEventListener('pointermove',event=>{
  if(!renderer?.scene)return;const p=coordinates(event);
  if(!gesture){stage.dataset.hover=renderer.hit(p)?'scratch':'';return;}
  if(gesture.pointer!==event.pointerId)return;
  if(gesture.type==='ink'){moveInk(p,performance.now());return;}
  if(!gesture.intent.move(p.x,p.y))return;
  const current=gesture,candidate=renderer.hit(p),hit=candidate?.channel===current.hit.channel?candidate:current.hit,scene=renderer.scene;
  const ring=scene.rings[current.hit.channel],along=bodyPoint(ring,Math.min(hit.s,ring.length),scene.bend),c=Math.cos(scene.view.rotation),s=Math.sin(scene.view.rotation);
  const tx=along.tx*c-along.ty*s,ty=along.tx*s+along.ty*c;
  const seconds=-((p.x-current.last.x)*tx+(p.y-current.last.y)*ty)/Math.max(30,ring.radius)*SCRATCH_INPUT.mouseSecondsPerRadian;
  const velocity=hand.push(seconds,eventTime(event));current.last=p;current.hit=hit;
  if(velocity!==null){current.velocity=velocity;if(current.ready)applyScratch(velocity,hit.angle);}
  beginScratch(current);
});
function pointerEnd(event){
  if(gesture?.pointer!==event.pointerId)return;
  const current=gesture,select=current.type==='body'&&current.intent.release(eventTime(event),event.type!=='pointerup')==='select';
  endGesture();if(select)openChannel(current.hit.channel,current.hit.angle);
}
for(const name of ['pointerup','pointercancel','lostpointercapture'])stage.addEventListener(name,pointerEnd);
stage.addEventListener('wheel',event=>{
  if(finale.state!=='ready')return;
  if(event.ctrlKey){
    event.preventDefault();if(pinch.wheel(event.deltaY,event.deltaMode,height)){clearTimeout(pinchTimer);const ticket=++pinchTicket;pinchTimer=setTimeout(()=>{if(ticket===pinchTicket&&pinch.source==='wheel')endPinch();},170);}return;
  }
  if(pinch.source){event.preventDefault();return;}
  if(!event.deltaY||gesture?.type==='scratch'||keyboard==='scratch')return;
  const hit=renderer?.hit(coordinates(event));if(!hit&&!wheel.active)return;
  event.preventDefault();if(!audio.playing){message('Нажми пробел, затем веди по телу.');return;}
  wheel.move({deltaY:event.deltaY,deltaMode:event.deltaMode,pageHeight:height,timeStamp:eventTime(event),inside:!!hit,angle:hit?.angle||0,momentum:typeof event.momentum==='boolean'?event.momentum:undefined});
},{passive:false});
stage.addEventListener('gesturestart',e=>{if(finale.state==='ready'){e.preventDefault();pinch.safariStart();}},{passive:false});
stage.addEventListener('gesturechange',e=>{e.preventDefault();if(finale.state==='ready')pinch.safariChange(e.scale);},{passive:false});
stage.addEventListener('gestureend',e=>{e.preventDefault();if(finale.state==='ready')pinch.safariChange(e.scale);endPinch();},{passive:false});
window.addEventListener('blur',pause);document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
window.addEventListener('keydown',event=>{
  const command=shortcut({code:event.code,key:event.key,ctrlKey:event.ctrlKey,metaKey:event.metaKey,altKey:event.altKey,tag:event.target.tagName,type:event.target.type,dialog:dialog.open});
  if(!command)return;
  event.preventDefault();
  if(command==='back'){closeView();return;}
  if(event.repeat)return;
  if(command==='play'){togglePlay();return;}
  if(command==='service'){endPinch();cancelGesture();dialog.showModal();return;}
  if(finale.state!=='ready')return;
  if(command==='smaller'||command==='larger'){endPinch();cancelGesture();pinch.set(pinch.scale*(command==='smaller'?.9:1/.9));return;}
  if(command.startsWith('part:')){cancelGesture();start().then(ok=>{if(ok)audio.cue(Number(command.slice(5))-1);});}
});
canvas.addEventListener('keydown',e=>{
  if(finale.state!=='ready')return;
  if(e.key==='ArrowUp'||e.key==='ArrowDown'){e.preventDefault();keyboardChannel=(keyboardChannel+(e.key==='ArrowDown'?1:2))%3;canvas.setAttribute('aria-label',RINGS[keyboardChannel].name+'. Enter — открыть настройки. Стрелки вверх и вниз — выбрать партию.');}
  if(e.key==='Enter'){e.preventDefault();openChannel(keyboardChannel);}
});
canvas.addEventListener('keydown',async e=>{
  if(!['ArrowLeft','ArrowRight'].includes(e.key)||finale.state!=='ready')return;e.preventDefault();
  if(!keyboard){wheel.cancel();keyboard='scratch';if(!await start()||keyboard!=='scratch')return;audio.grab();}
  applyScratch(e.key==='ArrowRight'?3.5:-3.5,-Math.PI/2);
});
canvas.addEventListener('keyup',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key))endGesture();});
inkButton.addEventListener('keydown',async e=>{
  if(finale.state!=='ready')return;
  if(e.key==='Enter'){e.preventDefault();if(e.repeat||keyboard)return;keyboard='ink';ink.touch(ink.fingerX,ink.fingerY);if(await start()&&keyboard==='ink')audio.startInk(.5+ink.fingerX*.5,.5-ink.fingerY*.5);}
  else if(e.key.startsWith('Arrow')){e.preventDefault();ink.fingerX=clamp(ink.fingerX+(e.key==='ArrowRight'?.08:e.key==='ArrowLeft'?-.08:0),-1,1);ink.fingerY=clamp(ink.fingerY+(e.key==='ArrowDown'?.08:e.key==='ArrowUp'?-.08:0),-1,1);audio.moveInk(.5+ink.fingerX*.5,.5-ink.fingerY*.5,.2);}
});
inkButton.addEventListener('keyup',e=>{if(e.key==='Enter')endGesture();});
for(const el of [canvas,inkButton])el.addEventListener('blur',()=>{if(keyboard)endGesture();});
function format(key,value){if(key==='brightness')return Math.round(value)+' Гц';if(key==='pan')return Math.abs(value)<.025?'Центр':(value<0?'Л ':'П ')+Math.round(Math.abs(value)*100)+'%';return Math.round(value*100)+'%';}
function populateControls(){
  const index=view.selected,state=audio.getChannelState(index);$('channel-title').textContent=RINGS[index].name;$('channel-number').textContent=['I','II','III'][index];
  $('wave-row').hidden=index===2;$('punch-row').hidden=index!==2;if(index<2)$('channel-wave').value=state.wave;
  for(const input of panel.querySelectorAll('[data-param]')){const key=input.dataset.param;input.value=state[key];panel.querySelector('[data-value="'+key+'"]').textContent=format(key,state[key]);}
  probe.dataset.selectedChannel=String(index);
}
for(const input of panel.querySelectorAll('[data-param]'))input.addEventListener('input',()=>{
  const key=input.dataset.param,value=Number(input.value);audio.setChannelParam(view.selected,key,value);panel.querySelector('[data-value="'+key+'"]').textContent=format(key,value);
  probe.dataset.channelSettings=JSON.stringify(audio.channelSettings);
});
$('channel-wave').addEventListener('change',async e=>{
  const index=view.selected;e.target.disabled=true;
  try{await audio.changeWave(index,e.target.value);}catch(error){message(error.message,true);}finally{e.target.disabled=false;if(index===view.selected)populateControls();}
});
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
for(const b of document.querySelectorAll('[data-scratch-mode]'))b.addEventListener('click',()=>{audio.setScratchMode(b.dataset.scratchMode);for(const choice of document.querySelectorAll('[data-scratch-mode]'))choice.setAttribute('aria-pressed',String(choice===b));});
function layoutInk(){
  const r=ringMetrics(2,baseRadius,pinch.scale).radius-baseRadius*RINGS[2].width*.65,size=Math.max(44,r*2);
  Object.assign(inkButton.style,{left:width/2-size/2+'px',top:height*.51-size/2+'px',width:size+'px',height:size+'px'});
}
function resize(){
  const rect=stage.getBoundingClientRect();width=rect.width;height=rect.height;baseRadius=sceneSize(width,height);
  renderer?.resize(width,height,devicePixelRatio||1);ink.resize(baseRadius);layoutInk();
}
function updateViewUi(scene){
  const p=view.progress;panel.hidden=p<.97||view.target===0||finale.state!=='ready';minimap.hidden=!scene.miniActive||finale.state!=='ready';inkButton.hidden=p>0||finale.state!=='ready';
  root.dataset.view=p>.1?'focus':'overview';
  if(lastSelected!==view.selected){lastSelected=view.selected;populateControls();}
  Object.assign(minimap.style,{left:scene.mini.x+'px',top:scene.mini.y+'px',width:scene.mini.size+'px',height:scene.mini.size+'px'});
  if(view.settled&&focusPending&&p===1&&!gesture&&!keyboard){focusPending=false;panel.querySelector(view.selected===2?'[data-param="punch"]':'select').focus({preventScroll:true});}
  if(view.settled&&returnFocus&&p===0&&!gesture&&!keyboard){returnFocus=false;canvas.focus({preventScroll:true});}
}
function frame(now){
  const dt=Math.min(.05,(now-lastFrame)/1000);lastFrame=now;view.update(dt,reduced.matches);
  const wasEnded=finale.state==='ended';finale.update(dt,reduced.matches);if(!wasEnded&&finale.state==='ended'){root.dataset.finale='ended';view.close(true);finale.pose=null;sync();}
  const analysis=audio.readAnalysis(),inner=ringMetrics(2,baseRadius,pinch.scale,0,finale.progress);
  ink.update(dt,analysis,Math.max(0,inner.radius-inner.thickness*.65),audio.playing,reduced.matches);
  let phase=model.phase;if(audio.playing)phase=wrap(phase+(now-lastStateAt)/1000*model.speed/(BEATS*60/BPM),1);
  const scene=renderer?.render({baseRadius,compression:pinch.scale,phase:reduced.matches?0:phase,viewState:view,ink,scratch:{angle:scratchVisual.angle,strength:scratchVisual.strengthAt(now),direction:scratchVisual.direction},finale:finale.progress,finalePose:finale.pose,reduced:reduced.matches});
  if(scene){
    updateViewUi(scene);
    if(finale.state==='ended'){const x=renderer.ctx;x.fillStyle='#000';x.beginPath();x.arc(width/2,height*.51,1.2,0,TAU);x.fill();}
    if(now-lastProbe>120){
      lastProbe=now;probe.dataset.view=view.progress===0?'overview':view.progress===1?'focus':'transition';probe.dataset.viewProgress=view.progress.toFixed(3);probe.dataset.finale=finale.state;probe.dataset.finaleProgress=finale.progress.toFixed(3);
      probe.dataset.rings=JSON.stringify(scene.rings.map(r=>({radius:r.radius,width:r.thickness,visibleLength:r.length,swallowed:r.swallowed,headAngle:r.headAngle})));
      probe.dataset.bodyPoints=JSON.stringify(scene.rings.map(r=>project(bodyPoint(r,r.length*.28,view.progress>0&&r.index===view.selected?scene.bend:0),view.progress>0&&r.index===view.selected?scene.view:scene.remaining)));
      probe.dataset.animationStage=scene.stage;probe.dataset.selectedVisible=String(scene.visible);probe.dataset.miniChannels=JSON.stringify(view.progress>0?[0,1,2].filter(i=>i!==view.selected):[]);probe.dataset.rotation='clockwise';
      root.dataset.level=analysis.level.toFixed(5);probe.dataset.channelLevels=JSON.stringify(Array.from(analysis.channels));probe.dataset.channelSettings=JSON.stringify(audio.channelSettings);
    }
  }
  requestAnimationFrame(frame);
}
try{
  renderer=new EngravingRenderer(canvas,$('ink-canvas'));new ResizeObserver(resize).observe(stage);resize();
  renderer.initialize().then(()=>message('')).catch(e=>message(e.message,true));requestAnimationFrame(frame);
}catch(e){message(e.message,true);}
populateControls();sync();
