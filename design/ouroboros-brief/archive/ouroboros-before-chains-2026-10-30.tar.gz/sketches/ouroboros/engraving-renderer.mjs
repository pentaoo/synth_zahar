import {TAU,RINGS,ATLAS,HEAD_UNITS,ringMetrics,bodyPoint,sampleBody,presentation,collapsePresentation,project,unproject,hitBody} from './body-geometry.mjs?v=ritual-7';
import {pairCreatures,creaturePoint,sampleCreature,ritualPresentation,hitCreature,eyePoint} from './ritual-geometry.mjs';
import {CREATURES,PHRASE_BEATS,phraseAt} from './ritual-model.mjs';
const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);};
const loadImage=async src=>{
  for(let attempt=0;attempt<3;attempt++){
    const im=new Image(),url=new URL(src);if(attempt)url.searchParams.set('retry',String(attempt));
    try{
      await new Promise((resolve,reject)=>{im.onload=resolve;im.onerror=reject;im.src=url.href;});
      // Some WebKit / embedded views reject decode after a successful load.
      try{await im.decode();}catch(error){if(!im.complete||!im.naturalWidth)throw error;}
      return im;
    }catch{if(attempt===2)throw new Error('Не загрузился атлас: '+src);}
  }
};
export class EngravingRenderer {
  constructor(canvas,inkCanvas){
    this.canvas=canvas;this.inkCanvas=inkCanvas;this.ctx=inkCanvas.getContext('2d');
    this.gl=canvas.getContext('webgl2',{alpha:false,antialias:true,preserveDrawingBuffer:true});
    if(!this.gl)throw new Error('Для растровой гравюры нужен WebGL 2. Открой инструмент в актуальном Chrome.');
    this.vertices=new Float32Array(514*2*4);this.path=new Float32Array(513*5);this.headVertices=new Float32Array(65*8);this.matrix=new Float32Array(9);this.segments=384;this.width=0;this.height=0;this.ready=false;
    this.grain=this.makeGrain();
  }
  async initialize(){
    const manifest=await (await fetch(new URL('./assets/ritual/skins.json',import.meta.url))).json();
    this.skins=manifest;this.assets={};
    const gl=this.gl;
    const shader=(type,source)=>{const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;};
    const vs=shader(gl.VERTEX_SHADER,`#version 300 es
      precision highp float; in vec2 a_position; in vec2 a_uv; uniform mat3 u_view; uniform vec2 u_resolution; out vec2 v_uv;
      void main(){vec3 p=u_view*vec3(a_position,1.);gl_Position=vec4(p.x/u_resolution.x*2.-1.,1.-p.y/u_resolution.y*2.,0.,1.);v_uv=a_uv;}`);
    const fs=shader(gl.FRAGMENT_SHADER,`#version 300 es
      precision highp float; in vec2 v_uv; uniform sampler2D u_texture; uniform float u_alpha; uniform bool u_skin; uniform vec4 u_crop; uniform vec4 u_eye; uniform vec3 u_life; out vec4 color;
      void main(){vec2 uv=v_uv;if(u_skin){uv.x=mix(u_crop.x,u_crop.y,1.-abs(fract(uv.x*.5)*2.-1.));uv.y=mix(u_crop.z,u_crop.w,uv.y);}
      else {vec2 q=(uv-u_eye.xy)/u_eye.zw;float inside=1.-smoothstep(.72,1.,length(q));uv+=u_life.yz*u_eye.zw*.12*inside;}
      color=texture(u_texture,uv);
      if(!u_skin){vec2 q=(v_uv-u_eye.xy)/u_eye.zw;float inside=1.-smoothstep(.9,1.06,length(q));float cover=inside*(u_life.x>.96?1.:smoothstep(1.-u_life.x-.04,1.-u_life.x+.04,abs(q.y)));
        if(u_life.x<.001)cover=0.;
        vec4 lid=texture(u_texture,vec2(v_uv.x+u_eye.z*2.6,u_eye.y-u_eye.w*.9+q.y*u_eye.w*.7));color=mix(color,lid,cover);if(u_life.x>.96&&abs(q.y-.14*(1.-q.x*q.x))<.07&&abs(q.x)<.82)color=vec4(0.,0.,0.,1.);}
      color.rgb=vec3(dot(color.rgb,vec3(.299,.587,.114)));color.a*=u_alpha;}`);
    this.program=gl.createProgram();gl.attachShader(this.program,vs);gl.attachShader(this.program,fs);gl.linkProgram(this.program);
    if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(this.program));
    gl.useProgram(this.program);this.buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.bufferData(gl.ARRAY_BUFFER,this.vertices.byteLength,gl.DYNAMIC_DRAW);
    for(const [name,size,offset] of [['a_position',2,0],['a_uv',2,8]]){const at=gl.getAttribLocation(this.program,name);gl.enableVertexAttribArray(at);gl.vertexAttribPointer(at,size,gl.FLOAT,false,16,offset);}
    this.uniforms={};for(const key of ['u_view','u_resolution','u_alpha','u_skin','u_crop','u_eye','u_life'])this.uniforms[key]=gl.getUniformLocation(this.program,key);
    const texture=image=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);return t;};
    // Upload one atlas at a time. Retain only its head alpha, not six full RGBA copies.
    for(const creature of CREATURES){
      const im=await loadImage(new URL(`./assets/ritual/${creature.id}.png?v=ritual-5`,import.meta.url)),mask=document.createElement('canvas');
      const maskWidth=Math.ceil(im.width*this.skins[creature.id].neck);mask.width=maskWidth;mask.height=im.height;
      const mc=mask.getContext('2d',{willReadFrequently:true});mc.drawImage(im,0,0);
      const rgba=mc.getImageData(0,0,maskWidth,im.height).data,alpha=new Uint8Array(maskWidth*im.height);for(let i=0;i<alpha.length;i++)alpha[i]=rgba[i*4+3];
      this.assets[creature.id]={width:im.width,height:im.height,maskWidth,alpha,texture:texture(im)};
    }
    gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);this.ready=true;
  }
  makeGrain(){
    const c=document.createElement('canvas');c.width=c.height=512;const x=c.getContext('2d');x.fillStyle='#070707';x.fillRect(0,0,512,512);
    let seed=7219;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
    for(let i=0;i<18000;i++){const px=random()*512,py=random()*512,r=.25+random()*.65;x.fillStyle=i%4?'#272727':'#e9e9e9';x.beginPath();x.ellipse(px,py,r,r*.65,random()*3,0,TAU);x.fill();}
    return c;
  }
  resize(width,height,dpr){this.width=width;this.height=height;this.dpr=Math.min(2,dpr||1);for(const c of [this.canvas,this.inkCanvas]){c.width=Math.round(width*this.dpr);c.height=Math.round(height*this.dpr);}this.gl.viewport(0,0,this.canvas.width,this.canvas.height);this.ctx.setTransform(this.dpr,0,0,this.dpr,0,0);this.pattern=this.ctx.createPattern(this.grain,'repeat');}
  setCamera(view){
    this.currentView=view;const gl=this.gl,c=Math.cos(view.rotation)*view.scale,s=Math.sin(view.rotation)*view.scale;
    const m=this.matrix;m[0]=c;m[1]=s;m[2]=0;m[3]=-s;m[4]=c;m[5]=0;m[6]=view.tx;m[7]=view.ty;m[8]=1;
    gl.uniformMatrix3fv(this.uniforms.u_view,false,m);
  }
  useCreature(ring,path=0){
    const gl=this.gl,a=ring.skin,life=this.life?.find(l=>l.id===ring.id);this.current=ring;
    gl.uniform4f(this.uniforms.u_crop,a.neck,a.end,a.top,a.bottom);gl.uniform4f(this.uniforms.u_eye,...a.eye);
    const e=creaturePoint(ring,(a.eye[0]-a.neck)/(a.bottom-a.top)*a.width/a.height*ring.thickness,path),rotation=this.currentView?.rotation||0,c=Math.cos(rotation),s=Math.sin(rotation),gx=life?.gazeX||0,gy=life?.gazeY||0;
    const tx=e.tx*c-e.ty*s,ty=e.tx*s+e.ty*c,nx=e.ty*c+e.tx*s,ny=e.ty*s-e.tx*c;
    gl.uniform3f(this.uniforms.u_life,life?.blink||0,-(gx*tx+gy*ty),-(gx*nx+gy*ny));
    gl.bindTexture(gl.TEXTURE_2D,this.assets[ring.id].texture);
  }
  body(ring,view,bend,alpha,scratch,ink,reduced,mini=false){
    if(ring.thickness<.01||ring.length<=0||alpha<=.001)return;
    const gl=this.gl,v=this.vertices,n=mini?96:this.segments,w=ring.thickness,path=sampleCreature(ring,bend,n,this.path);
    for(let j=0;j<=n;j++){
      const at=j*5,material=path[at+4],p={x:path[at],y:path[at+1],tx:path[at+2],ty:path[at+3]},angle=Math.atan2(p.y,p.x);
      const delta=Math.atan2(Math.sin(angle-scratch.angle),Math.cos(angle-scratch.angle));
      const neck=smooth(material/Math.max(1,ring.baseWidth));
      const local=Math.exp(-delta*delta/(2*.2*.2))*scratch.strength*neck;
      const tooth=.5+.5*Math.cos(material/(ring.baseWidth*.19)*TAU);
      const life=this.life?.find(l=>l.id===ring.id),tension=life?.tension||0;
      const rise=reduced?0:(local*w*(.16+.2*tooth)+tension*w*.045*tooth*neck);
      const lean=reduced?0:local*scratch.direction*w*.12;
      const press=ring.index===2&&bend===0?ink.pressureAt(angle)*w*.22*neck:0;
      const taper=ring.fullLength-material<ring.baseWidth*2.7?Math.max(.10,(ring.fullLength-material)/(ring.baseWidth*2.7)):1;
      for(let side=0;side<2;side++){
        const amount=(side===0?-1:1)*w*.5*taper-(side===0?rise:0)-press;
        const k=(j*2+side)*4;v[k]=p.x+p.ty*amount+(side===0?p.tx*lean:0);v[k+1]=p.y-p.tx*amount+(side===0?p.ty*lean:0);v[k+2]=material/ring.tileLength;v[k+3]=side;
      }
    }
    this.setCamera(view);this.useCreature(ring,bend);gl.uniform1f(this.uniforms.u_alpha,alpha);gl.uniform1i(this.uniforms.u_skin,1);gl.bindTexture(gl.TEXTURE_2D,this.assets[ring.id].texture);gl.bufferSubData(gl.ARRAY_BUFFER,0,v.subarray(0,(n+1)*8));gl.drawArrays(gl.TRIANGLE_STRIP,0,(n+1)*2);

  }
  head(ring,alpha,path=0,mini=false){
    this.useCreature(ring,path);const atlas=ring.skin;
    const gl=this.gl,w=ring.thickness,v=this.headVertices,n=mini?24:64;
    for(let j=0;j<=n;j++){
      const u=j/n*atlas.neck,p=creaturePoint(ring,(j/n-1)*w*ring.headUnits,path);
      for(let side=0;side<2;side++){
        const y=(side-atlas.center)/(atlas.bottom-atlas.top)*w,k=(j*2+side)*4;
        v[k]=p.x+p.ty*y;v[k+1]=p.y-p.tx*y;v[k+2]=u;v[k+3]=side;
      }
    }
    gl.uniform1i(this.uniforms.u_skin,0);gl.uniform1f(this.uniforms.u_alpha,alpha);gl.bindTexture(gl.TEXTURE_2D,this.assets[ring.id].texture);gl.bufferSubData(gl.ARRAY_BUFFER,0,v.subarray(0,(n+1)*8));gl.drawArrays(gl.TRIANGLE_STRIP,0,(n+1)*2);
  }
  headHit(point,creatures,view,path=0){
    const p=unproject(point,view);
    for(const ring of creatures){
      const atlas=ring.skin,asset=this.assets[ring.id];if(ring.thickness<.01)continue;
      for(let j=0;j<=48;j++){
        const material=(j/48-1)*ring.thickness*ring.headUnits,a=creaturePoint(ring,material,path),dx=p.x-a.x,dy=p.y-a.y;
        const along=dx*a.tx+dy*a.ty;if(Math.abs(along)>ring.thickness*ring.headUnits/48)continue;
        const u=(material+along)/(ring.thickness*ring.headUnits)*atlas.neck+atlas.neck,v=(dx*a.ty-dy*a.tx)/ring.thickness*(atlas.bottom-atlas.top)+atlas.center;
        if(u<0||u>=atlas.neck||v<0||v>=1)continue;
        const at=Math.floor(v*asset.height)*asset.maskWidth+Math.floor(u*asset.width);
        if(asset.alpha[at]>110)return {channel:ring.channel,phraseId:ring.id,part:ring.part,s:ring.offset+material,angle:Math.atan2(p.y,p.x),ring,distance:0};
      }
    }return null;
  }
  hit(point){
    if(!this.ready||!this.scene||!this.scene.visible)return null;
    const {creatures,view,bend,focus,remaining}=this.scene;
    const selected=focus<0?creatures:creatures.filter(c=>c.channel===focus);
    return this.headHit(point,selected,focus<0?remaining:view,focus<0?0:bend)||hitCreature(point,selected,focus<0?remaining:view,focus<0?0:bend);
  }
  signs(creatures,view,path,mini){
    if(mini)return;const x=this.ctx;
    for(const c of creatures){if(c.thickness<.5||c.length<1)continue;const life=this.life?.find(l=>l.id===c.id),p=creaturePoint(c,c.length*.45,path),a=project(p,view),normal={x:p.ty,y:-p.tx};
      const fx=life?.effects||{},strength=Math.max(fx.vault||0,fx.rage||0,fx.split||0);
      
      const gap=(c.thickness*.7+9/view.scale)*view.scale;x.save();x.translate(a.x+normal.x*gap,a.y+normal.y*gap);x.strokeStyle='#000';x.fillStyle='#000';x.lineWidth=1;x.font='17px Georgia';x.textAlign='center';x.textBaseline='middle';
      x.fillText(fx.rage>.1?'ᚦ':fx.vault>.1?'ᛝ':fx.split>.1?'ᛯ':c.rune,0,0);
      x.beginPath();x.arc(10,-10,1.8,0,TAU);if(life?.active)x.fill();else x.stroke();
      if(life.selected){x.beginPath();x.arc(0,0,14,0,TAU);x.stroke();}
      if(strength>.01){x.beginPath();x.arc(0,0,18,-Math.PI/2,-Math.PI/2+TAU*strength);x.stroke();}
      x.restore();
    }
  }
  ink(ink,view,windowRadius,alpha=1){
    if(alpha<.001||windowRadius<=0)return;
    const ctx=this.ctx,c=Math.cos(view.rotation)*view.scale,s=Math.sin(view.rotation)*view.scale;
    ctx.save();ctx.transform(c,s,-s,c,view.tx,view.ty);ctx.globalAlpha=alpha;
    ctx.beginPath();ctx.arc(0,0,windowRadius,0,TAU);ctx.clip();
    const p=ink.points,n=ink.count;ctx.beginPath();ctx.moveTo((p[0]+p[(n-1)*2])/2,(p[1]+p[(n-1)*2+1])/2);
    for(let i=0;i<n;i++){const next=(i+1)%n;ctx.quadraticCurveTo(p[i*2],p[i*2+1],(p[i*2]+p[next*2])/2,(p[i*2+1]+p[next*2+1])/2);}ctx.closePath();ctx.fillStyle=this.pattern;ctx.fill();
    for(const d of ink.droplets){ctx.beginPath();ctx.ellipse(d.x,d.y,d.r,d.r*.82,Math.atan2(d.vy,d.vx),0,TAU);ctx.fill();}
    ctx.restore();
  }
  render({baseRadius,compression,phase,viewState,ink,scratch,life=[],finale=0,finalePose=null,reduced=false}){
    if(!this.ready)return;this.life=life;
    const gl=this.gl,{width,height}=this,p=viewState.progress;
    const rings=RINGS.map((spec,i)=>({...ringMetrics(i,baseRadius,compression,phase,finale),baseRadius,ratio:spec.ratio}));
    const lead=viewState.leadPart||0,selectedRing=rings[viewState.selected];selectedRing.headAngle-=lead?TAU*PHRASE_BEATS[0]/PHRASE_BEATS.reduce((a,b)=>a+b,0):0;const leadSkin=this.skins[CREATURES[viewState.selected*2+lead].id];
    selectedRing.headUnits=leadSkin.neck/(leadSkin.bottom-leadSkin.top)*leadSkin.width/leadSkin.height;
    let layout=ritualPresentation(width,height,baseRadius,selectedRing,viewState);
    if(finalePose)layout=collapsePresentation(layout,finalePose,finale);
    const {view,overview,remaining,mini}=layout;let bend=layout.path;
    if(p===1&&!finalePose){
      if(!viewState.live){viewState.phaseAnchor=phase;viewState.angleAnchor=viewState.focusAngle;viewState.live=true;}
      selectedRing.headAngle=viewState.angleAnchor+(phase-viewState.phaseAnchor)*TAU;
    }else selectedRing.headAngle=layout.angle;
    viewState.displayAngle=selectedRing.headAngle;
    const creatures=rings.flatMap(r=>pairCreatures(r,r.index===viewState.selected?lead:0,this.skins));
    const chosen=creatures.filter(c=>c.channel===viewState.selected),others=creatures.filter(c=>c.channel!==viewState.selected);
    if(bend)bend={...bend,headLength:chosen[0].thickness*chosen[0].headUnits};
    gl.disable(gl.SCISSOR_TEST);gl.clearColor(1,1,1,1);gl.clear(gl.COLOR_BUFFER_BIT);gl.useProgram(this.program);gl.uniform2f(this.uniforms.u_resolution,width,height);this.ctx.clearRect(0,0,width,height);
    const draw=(group,camera,path,small=false)=>{for(const c of group)this.body(c,camera,path,1,scratch,ink,reduced,small);this.setCamera(camera);for(const c of group)this.head(c,1,path,small);this.signs(group,camera,path,small);};
    if(layout.visible)draw(chosen,view,bend);
    draw(others,remaining,0,p>.54);
    const windowRadius=Math.max(0,rings[2].radius-rings[2].thickness*.65);this.ink(ink,remaining,windowRadius,1);
    if(layout.mobile&&p>=.54){
      // The mobile miniature includes the selected pair, without a second audio source.
      const miniRing={...selectedRing,headAngle:RINGS[viewState.selected].angle+phase*TAU};
      draw(pairCreatures(miniRing,0,this.skins),remaining,0,true);
    }
    const eyes={};for(const c of creatures){const camera=p>0&&c.channel===viewState.selected?view:remaining;eyes[c.id]=project(eyePoint(c,c.channel===viewState.selected?bend:0),camera);}
    this.scene={rings,creatures,eyes,view,bend,focus:p>0?viewState.selected:-1,overview,remaining,windowRadius,mini,miniActive:layout.miniActive,visible:layout.visible,stage:layout.stage,mobile:layout.mobile};return this.scene;
  }
}
